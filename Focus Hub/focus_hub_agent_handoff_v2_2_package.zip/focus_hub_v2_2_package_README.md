# Focus Hub v2.2 交接包

**主文档**：`focus_hub_agent_handoff_v2_2.md`。以该文档为最新约束；v2 HTML 只是前端原型。

## 阅读顺序
1. `focus_hub_agent_handoff_v2_2.md` 第 0 和 0.5 节：流式会话→立体推进网络，历史遗漏/挂起/恢复。
2. 文档第 2/4/5/6/7/8 节：视图交互约束、数据模型、实施计划、测试。
3. `task_focus_hub_v2.html`：阅读现有代码和点击验证 L1/L2/L3。
4. `project_focus_hub_design.md`：历史设计理念。
5. `focus_hub_v2_2_history_fixture.jsonl`：仅供测试的虚构会话事件。

## 不能混淆
- 新的历史遗漏扫描和可恢复 Capsule 是 v2.2 **设计需求，不是当前 HTML 已实现的功能**。
- 对一个用户请求没有继续讨论，不代表该请求已完成或取消。
- JSONL 示例数据是虚构的开发测试数据，不能用于真实项目汇报。

## 最小下一步
在现有 HTML 增加“未闭环/待接续”入口和 Resume Capsule 的人工管理，再用 JSONL fixture 做一次历史线索抽取/归属/恢复的端到端演示。
